#define IDI_APPICON                    101
#define IDR_MAINMENU                   102
#define IDR_ACCELERATOR                103
#define IDD_ABOUTDIALOG                104
#define ID_FILE_EXIT                   40001
#define ID_HELP_ABOUT                  40002

#ifndef IDC_STATIC
  #define IDC_STATIC                   -1
#endif
